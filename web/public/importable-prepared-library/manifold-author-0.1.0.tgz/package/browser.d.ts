import type { GraphWorkspaceProject, PreparedRoute, ParameterEdit } from './index.js';

export type PreparedGraphDiagnostics = Readonly<{
  execution: 'prepared'; audioBlocks: number; rustProcessedBlocks: number; publications: number;
  rustProcessingFailures: number; rustCallbackAllocations: number; rustCallbackDeallocations: number;
  lastTransferredNodes: number; lastPublicationContextFrame: number; outputLatencyBlocks: 0;
  memoryBytes: number; lastPreparationMs: number | null; lastPublicationMs: number | null;
  compilerFailed: boolean; processorFailed: boolean;
}>;

export class BrowserGraphHost {
  constructor(context: AudioContext, options?: { workletUrl?: string | URL; wasmUrl?: string | URL;
    execution?: 'worklet' | 'worker' | 'prepared'; workerUrl?: string | URL; workerWorkletUrl?: string | URL; profiling?: boolean;
    preparedWasmUrl?: string | URL; preparedWorkletUrl?: string | URL; preparedCompilerUrl?: string | URL });
  readonly ready: boolean;
  readonly diagnostics: PreparedGraphDiagnostics | Readonly<{ execution: 'worker'; audioBlocks: number; underruns: number;
    pendingRetirements: number; lastRetirementMs: number | null;
    activeSlot: number; outputLatencyBlocks: number;
    deferredPublicationBlocks: number; publications: number; lastPublicationTarget: number;
    maxRenderLagBlocks: number; workerLateBlocks: number; missingOutputBlocks: number;
    frameMismatchBlocks: number; startupMutedBlocks: number;
    recentUnderruns: readonly Readonly<{ audioSequence: number; target: number; activeSlot: number;
      outputTag: number; renderedSequence: number; reason: string; pendingPublication: number; contextFrame: number }>[];
    lastPreparationMs: number | null; lastPublicationMs: number | null;
    lastTransferredNodes: number | null }> | null;
  readonly workerProfile: Readonly<{ blocks: number; p50Us: number; p95Us: number;
    p99Us: number; maxUs: number; service: Readonly<{ blocks: number; p50Us: number;
      p95Us: number; p99Us: number; maxUs: number }> | null }> | null;
  prepare(project: GraphWorkspaceProject, options?: { patchable?: boolean }): Promise<this>;
  connect(source: AudioNode | null, destination?: AudioNode, sidechainSource?: AudioNode | null): this;
  readPublishedParameters(): ParameterEdit[];
  setRoute(route: PreparedRoute): Promise<void>;
  setParameter(edit: ParameterEdit): Promise<void>;
  setParameterBatch(edits: readonly ParameterEdit[]): Promise<void>;
  replaceGraph(project: GraphWorkspaceProject): Promise<void>;
  captureWindow(captureId: number, window?: number | Readonly<{
    windowSeconds?: number; windowBars?: number; tempoBpm?: number; freeStop?: boolean;
    meterNumerator?: number; meterDenominator?: number; manualStartOffsetFrames?: number;
  }>): Promise<{
    sourceRate: number; stereo: Float32Array;
  }>;
  snapshotLoop(captureId: number): Promise<{ sourceRate: number; stereo: Float32Array }>;
  armFreeCapture(captureId: number): Promise<{ startOffset: number; capacity: number }>;
  captureCursor(captureId: number): Promise<{ startOffset: number; capacity: number }>;
  cancelFreeCapture(): void;
  replaceSample(nodeId: number, sourceRate: number, stereo: Float32Array,
    bindingTargets?: readonly number[]): Promise<void>;
  sendEvent(event: { nodeId: number; kind: 0 | 1 | 2; channel?: number;
    note?: number; velocity?: number; offset?: number }): void;
  close(): void | Promise<void>;
}
