import type { GraphWorkspaceProject, ParameterEdit, PreparedRoute } from './index.js';

export interface ProjectPackage {
  readonly format: 'manifold.package';
  readonly schemaVersion: 1;
  readonly packageId: string;
  readonly packageVersion: string;
  readonly control: Readonly<{
    language: 'javascript';
    format: 'iife';
    bundle: string;
    sha256: string;
  }>;
  readonly state: GraphWorkspaceProject;
}

export interface PackageHost {
  readPublishedParameters?(): readonly ParameterEdit[] | Promise<readonly ParameterEdit[]>;
  setParameter(edit: ParameterEdit): Promise<void | boolean> | void | boolean;
  setRoute(route: PreparedRoute): Promise<void | boolean> | void | boolean;
  replaceGraph?(project: GraphWorkspaceProject): Promise<void | boolean> | void | boolean;
}

export interface PackageController {
  synchronizeParameters?(): Promise<GraphWorkspaceProject>;
  adoptPublishedParameters?(edits: readonly ParameterEdit[]): Promise<GraphWorkspaceProject>;
  toProject(): GraphWorkspaceProject;
  set(path: string, value: number): Promise<GraphWorkspaceProject>;
}

export function readProjectPackage(input: string | ProjectPackage): Promise<ProjectPackage>;
export function instantiateProjectPackage(input: string | ProjectPackage, host: PackageHost): Promise<{
  package: ProjectPackage;
  controller: PackageController;
}>;
export function saveProjectPackage(packaged: ProjectPackage, project: GraphWorkspaceProject): ProjectPackage;
