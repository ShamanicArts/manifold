// Behavior transposed from DspLiveScripting/dsp/default_dsp.lua.
// A generic host supplies audio I/O and the acknowledged route/parameter callbacks.
import { GraphWorkspace, createGraphWorkspace, createLiveGraphSession } from '../index.js';

export const parameters = Object.freeze({
  '/dsp/live/input_gain': Object.freeze({ nodeId: 4, id: 0, min: 0, max: 2, default: 1 }),
  '/dsp/live/width': Object.freeze({ nodeId: 5, id: 0, min: 0, max: 1, default: 0.25 }),
});

export function buildGraph() {
  const graph = createGraphWorkspace().setInputSource('external');
  const gain = graph.add('gain', { id: 4 });
  const width = graph.add('stereo-widener', { id: 5 });
  graph.registerInstance('/dsp/live/nodes/input_trim', gain);
  graph.registerInstance('/dsp/live/nodes/width', width);
  graph.setParameter(gain, 0, parameters['/dsp/live/input_gain'].default);
  graph.setParameter(width, 0, parameters['/dsp/live/width'].default);
  graph.registerParameter('/dsp/live/input_gain', gain, 0, parameters['/dsp/live/input_gain']);
  graph.registerParameter('/dsp/live/width', width, 0, parameters['/dsp/live/width']);
  graph.bindHostSlot(0, gain, 0);
  graph.bindHostSlot(1, width, 0);
  graph.connect(graph.input.output('out'), gain.input('audio'));
  graph.connect(gain.output('out'), width.input('audio'));
  graph.connect(width.output('out'), graph.output.input('in'));
  return graph;
}

export function createProject(host, graph = buildGraph()) {
  const session = createLiveGraphSession(graph,
    route => host.setRoute(route), edit => host.setParameter(edit),
    typeof host.replaceGraph === 'function' ? graph => host.replaceGraph(graph) : null,
    null, typeof host.readPublishedParameters === 'function' ? () => host.readPublishedParameters() : null);
  return Object.freeze({
    session,
    toProject: () => session.toProject(),
    adoptPublishedParameters: edits => session.adoptPublishedParameters(edits),
    synchronizeParameters: () => session.adoptPublishedParameters([]),
    set: (path, value) => session.parameterPath(path, value),
    routeOutput: (sourcePath) => {
      const source = session.forkGraph().findInstance(sourcePath);
      if (!source) throw new Error(`Unknown graph instance: ${sourcePath}`);
      return session.route({ to: 3, input: 'in', from: source.id, output: 'out' });
    },
    setDistortion: enabled => session.transaction(graph => {
      const gain = graph.findInstance('/dsp/live/nodes/input_trim');
      const width = graph.findInstance('/dsp/live/nodes/width');
      const existing = graph.findInstance('/dsp/live/nodes/distortion');
      if (enabled && !existing) {
        const distortion = graph.add('distortion', { id: 6 });
        graph.registerInstance('/dsp/live/nodes/distortion', distortion);
        graph.setParameter(distortion, 0, 4);
        graph.setParameter(distortion, 1, 1);
        graph.setParameter(distortion, 2, 1);
        graph.disconnect(width.input('audio'));
        graph.connect(gain.output('out'), distortion.input('audio'));
        graph.connect(distortion.output('out'), width.input('audio'));
      } else if (!enabled && existing) {
        graph.remove(existing);
        graph.connect(gain.output('out'), width.input('audio'));
      }
    }),
  });
}

export function restoreProject(host, saved) {
  const graph = GraphWorkspace.fromProject(saved);
  if (graph.findInstance('/dsp/live/nodes/input_trim')?.type !== 'gain') {
    throw new Error('Saved DspLiveScripting graph is missing its input trim');
  }
  return createProject(host, graph);
}
