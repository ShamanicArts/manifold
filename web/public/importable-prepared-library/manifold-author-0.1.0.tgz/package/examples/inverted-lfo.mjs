import { createGraphWorkspace } from '../index.js';

const graph = createGraphWorkspace();
const tone = graph.add('oscillator', { id: 4 });
const lfo = graph.add('lfo', { id: 5 });
const gain = graph.add('modulated-gain', { id: 6 });

graph.connect(tone.output('out'), gain.input('audio'));
graph.connect(lfo.output('inv'), gain.input('cv'));
graph.connect(gain.output('out'), graph.output.input('in'));

console.log(JSON.stringify(graph.toProject(), null, 2));
