// Public graph composition for the historical Sample module's pitch stage.
// The oscillator is a deterministic test source; a sample voice can replace it.
import { createGraphWorkspace, createLiveGraphSession } from '../index.js';

export function buildGraph() {
  const graph = createGraphWorkspace();
  const source = graph.add('oscillator', { id: 4 });
  const vocoder = graph.add('phase-vocoder', { id: 5 });
  graph.registerInstance('/sample/voice/source', source);
  graph.registerInstance('/sample/voice/vocoder', vocoder);
  graph.setParameter(source, 0, 0);
  graph.setParameter(source, 1, 440);
  graph.setParameter(source, 2, 0.4);
  graph.setParameter(vocoder, 0, 0);
  graph.setParameter(vocoder, 1, 12);
  graph.setParameter(vocoder, 3, 1);
  graph.setParameter(vocoder, 4, 9);
  graph.registerParameter('/sample/voice/pitch', vocoder, 1,
    { min: -24, max: 24, default: 12 });
  graph.registerParameter('/sample/voice/mix', vocoder, 3,
    { min: 0, max: 1, default: 1 });
  graph.connect(source.output('out'), vocoder.input('audio'));
  graph.connect(vocoder.output('out'), graph.output.input('in'));
  return graph;
}

export function createProject(host, graph = buildGraph()) {
  const session = createLiveGraphSession(graph,
    route => host.setRoute(route), edit => host.setParameter(edit));
  return { set: (path, value) => session.parameterPath(path, value),
    toProject: () => session.toProject(), session };
}
