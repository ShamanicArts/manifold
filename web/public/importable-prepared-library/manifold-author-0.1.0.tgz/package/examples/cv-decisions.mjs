// Compare emits separate gate and two-block trigger ports; Range maps the gate.
import { createGraphWorkspace } from '../index.js';

const graph = createGraphWorkspace();
const tone = graph.add('oscillator', { id: 4 });
const lfo = graph.add('lfo', { id: 5 });
const compare = graph.add('cv-compare', { id: 6 });
const range = graph.add('cv-range', { id: 7 });
const mix = graph.add('cv-mix', { id: 8 });
const gain = graph.add('modulated-gain', { id: 9 });

graph.setParameter(lfo, 1, 20);
graph.setParameter(compare, 0, 2);
graph.setParameter(compare, 1, 0.2);
graph.setParameter(range, 0, 0.1);
graph.setParameter(range, 1, 0.8);
graph.setParameter(range, 2, 1);
graph.setParameter(mix, 0, 0.5);
graph.setParameter(mix, 1, 0.5);

graph.connect(lfo.output('out'), compare.input('cv'));
graph.connect(compare.output('gate'), range.input('cv'));
graph.connect(range.output('out'), mix.input('in-1'));
graph.connect(compare.output('trig'), mix.input('in-2'));
graph.connect(mix.output('out'), gain.input('cv'));
graph.connect(tone.output('out'), gain.input('audio'));
graph.connect(gain.output('out'), graph.output.input('in'));

console.log(JSON.stringify(graph.toProject(), null, 2));
