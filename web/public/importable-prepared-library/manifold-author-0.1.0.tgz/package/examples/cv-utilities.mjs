// The same authored CV patch runs in browser/Wasm and native hosts.
import { createGraphWorkspace } from '../index.js';

const graph = createGraphWorkspace();
const tone = graph.add('oscillator', { id: 4 });
const lfo = graph.add('lfo', { id: 5 });
const amount = graph.add('attenuverter-bias', { id: 6 });
const slew = graph.add('slew-control', { id: 7 });
const hold = graph.add('sample-hold', { id: 8 });
const mix = graph.add('cv-mix', { id: 9 });
const gain = graph.add('modulated-gain', { id: 10 });

graph.setParameter(lfo, 1, 5);
graph.setParameter(amount, 0, -0.8);
graph.setParameter(amount, 1, 0.2);
graph.setParameter(slew, 0, 24);
graph.setParameter(slew, 1, 80);
graph.setParameter(mix, 1, 0.3);

graph.connect(lfo.output('out'), amount.input('cv'));
graph.connect(amount.output('out'), slew.input('cv'));
graph.connect(slew.output('out'), hold.input('cv'));
graph.connect(lfo.output('uni'), hold.input('trigger'));
graph.connect(hold.output('out'), mix.input('in-1'));
graph.connect(lfo.output('inv'), mix.input('in-2'));
graph.connect(mix.output('out'), gain.input('cv'));
graph.connect(tone.output('out'), gain.input('audio'));
graph.connect(gain.output('out'), graph.output.input('in'));

console.log(JSON.stringify(graph.toProject(), null, 2));
