// Generated from manifold-core graph metadata. Run scripts/update-port-catalog.sh.
export const PORT_CATALOG = {
  "attenuverter-bias": {
    "args": {
      "a": 1.0,
      "b": 0.0
    },
    "code": 31,
    "inputs": [
      {
        "name": "cv",
        "signal": "control"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "control"
      }
    ],
    "parameters": [
      {
        "default": 1.0,
        "discrete": false,
        "id": 0,
        "max": 1.0,
        "min": -1.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 1,
        "max": 1.0,
        "min": -1.0
      }
    ]
  },
  "audio-fm": {
    "args": {},
    "code": 71,
    "inputs": [
      {
        "name": "carrier",
        "signal": "audio"
      },
      {
        "name": "modulator",
        "signal": "audio"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 0.0,
        "discrete": false,
        "id": 0,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 1,
        "max": 1.0,
        "min": 0.0
      }
    ]
  },
  "audio-sync": {
    "args": {},
    "code": 72,
    "inputs": [
      {
        "name": "carrier",
        "signal": "audio"
      },
      {
        "name": "modulator",
        "signal": "audio"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 0.0,
        "discrete": false,
        "id": 0,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 1,
        "max": 1.0,
        "min": 0.0
      }
    ]
  },
  "crossfader": {
    "args": {
      "a": 0.0,
      "b": 1.0
    },
    "code": 8,
    "inputs": [
      {
        "name": "a",
        "signal": "audio"
      },
      {
        "name": "b",
        "signal": "audio"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 0.0,
        "discrete": false,
        "id": 0,
        "max": 1.0,
        "min": -1.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 1,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 2,
        "max": 1.0,
        "min": 0.0
      }
    ]
  },
  "cv-compare": {
    "args": {},
    "code": 68,
    "inputs": [
      {
        "name": "cv",
        "signal": "control"
      }
    ],
    "outputs": [
      {
        "name": "gate",
        "signal": "control"
      },
      {
        "name": "trig",
        "signal": "control"
      }
    ],
    "parameters": [
      {
        "default": 0.0,
        "discrete": true,
        "id": 0,
        "max": 2.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 1,
        "max": 1.0,
        "min": -1.0
      },
      {
        "default": 0.05,
        "discrete": false,
        "id": 2,
        "max": 0.5,
        "min": 0.0
      }
    ]
  },
  "cv-mix": {
    "args": {
      "a": 1.0,
      "b": 0.5
    },
    "code": 33,
    "inputs": [
      {
        "name": "in-1",
        "signal": "control"
      },
      {
        "name": "in-2",
        "signal": "control"
      },
      {
        "name": "in-3",
        "signal": "control"
      },
      {
        "name": "in-4",
        "signal": "control"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "control"
      }
    ],
    "parameters": [
      {
        "default": 1.0,
        "discrete": false,
        "id": 0,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.5,
        "discrete": false,
        "id": 1,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 2,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 3,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 4,
        "max": 1.0,
        "min": -1.0
      }
    ]
  },
  "cv-range": {
    "args": {},
    "code": 69,
    "inputs": [
      {
        "name": "cv",
        "signal": "control"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "control"
      }
    ],
    "parameters": [
      {
        "default": 0.0,
        "discrete": false,
        "id": 0,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 1,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 2,
        "max": 1.0,
        "min": 0.0
      }
    ]
  },
  "distortion": {
    "args": {
      "a": 4.0,
      "b": 0.7
    },
    "code": 17,
    "inputs": [
      {
        "name": "audio",
        "signal": "audio"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 4.0,
        "discrete": false,
        "id": 0,
        "max": 30.0,
        "min": 1.0
      },
      {
        "default": 0.7,
        "discrete": false,
        "id": 1,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.8,
        "discrete": false,
        "id": 2,
        "max": 2.0,
        "min": 0.0
      }
    ]
  },
  "effect-slot-legacy": {
    "args": {
      "a": 0.0,
      "b": 0.0
    },
    "code": 52,
    "inputs": [
      {
        "name": "audio",
        "signal": "audio"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 0.0,
        "discrete": true,
        "id": 0,
        "max": 20.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 1,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.5,
        "discrete": false,
        "id": 2,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.5,
        "discrete": false,
        "id": 3,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.2,
        "discrete": false,
        "id": 4,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.6,
        "discrete": false,
        "id": 5,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.4,
        "discrete": false,
        "id": 6,
        "max": 1.0,
        "min": 0.0
      }
    ]
  },
  "eq8": {
    "args": {},
    "code": 36,
    "inputs": [
      {
        "name": "audio",
        "signal": "audio"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 0.0,
        "discrete": true,
        "id": 0,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 1.0,
        "discrete": true,
        "id": 1,
        "max": 6.0,
        "min": 0.0
      },
      {
        "default": 60.0,
        "discrete": false,
        "id": 2,
        "max": 20000.0,
        "min": 20.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 3,
        "max": 24.0,
        "min": -24.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 4,
        "max": 24.0,
        "min": 0.1
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 5,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 6,
        "max": 6.0,
        "min": 0.0
      },
      {
        "default": 120.0,
        "discrete": false,
        "id": 7,
        "max": 20000.0,
        "min": 20.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 8,
        "max": 24.0,
        "min": -24.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 9,
        "max": 24.0,
        "min": 0.1
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 10,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 11,
        "max": 6.0,
        "min": 0.0
      },
      {
        "default": 250.0,
        "discrete": false,
        "id": 12,
        "max": 20000.0,
        "min": 20.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 13,
        "max": 24.0,
        "min": -24.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 14,
        "max": 24.0,
        "min": 0.1
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 15,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 16,
        "max": 6.0,
        "min": 0.0
      },
      {
        "default": 500.0,
        "discrete": false,
        "id": 17,
        "max": 20000.0,
        "min": 20.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 18,
        "max": 24.0,
        "min": -24.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 19,
        "max": 24.0,
        "min": 0.1
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 20,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 21,
        "max": 6.0,
        "min": 0.0
      },
      {
        "default": 1000.0,
        "discrete": false,
        "id": 22,
        "max": 20000.0,
        "min": 20.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 23,
        "max": 24.0,
        "min": -24.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 24,
        "max": 24.0,
        "min": 0.1
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 25,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 26,
        "max": 6.0,
        "min": 0.0
      },
      {
        "default": 2500.0,
        "discrete": false,
        "id": 27,
        "max": 20000.0,
        "min": 20.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 28,
        "max": 24.0,
        "min": -24.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 29,
        "max": 24.0,
        "min": 0.1
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 30,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 31,
        "max": 6.0,
        "min": 0.0
      },
      {
        "default": 6000.0,
        "discrete": false,
        "id": 32,
        "max": 20000.0,
        "min": 20.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 33,
        "max": 24.0,
        "min": -24.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 34,
        "max": 24.0,
        "min": 0.1
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 35,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 2.0,
        "discrete": true,
        "id": 36,
        "max": 6.0,
        "min": 0.0
      },
      {
        "default": 12000.0,
        "discrete": false,
        "id": 37,
        "max": 20000.0,
        "min": 20.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 38,
        "max": 24.0,
        "min": -24.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 39,
        "max": 24.0,
        "min": 0.1
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 40,
        "max": 24.0,
        "min": -24.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 41,
        "max": 1.0,
        "min": 0.0
      }
    ]
  },
  "extended-oscillator": {
    "args": {
      "a": 220.0,
      "b": 0.0
    },
    "code": 73,
    "inputs": [
      {
        "name": "sync",
        "signal": "audio"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 1.0,
        "discrete": true,
        "id": 0,
        "max": 7.0,
        "min": 0.0
      },
      {
        "default": 220.0,
        "discrete": false,
        "id": 1,
        "max": 16000.0,
        "min": 20.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 2,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 3,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.5,
        "discrete": false,
        "id": 4,
        "max": 0.99,
        "min": 0.01
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 5,
        "max": 20.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 6,
        "max": 3.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 7,
        "max": 1.0,
        "min": -1.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 8,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 9,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 10,
        "max": 8.0,
        "min": 1.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 11,
        "max": 100.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 12,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 13,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 8.0,
        "discrete": false,
        "id": 14,
        "max": 32.0,
        "min": 1.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 15,
        "max": 1.0,
        "min": -1.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 16,
        "max": 1.0,
        "min": 0.0
      }
    ]
  },
  "fixed-gain": {
    "args": {
      "a": 4.0
    },
    "code": 67,
    "inputs": [
      {
        "name": "audio",
        "signal": "audio"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": []
  },
  "gain": {
    "args": {
      "a": 0.7
    },
    "code": 3,
    "inputs": [
      {
        "name": "audio",
        "signal": "audio"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 0.7,
        "discrete": false,
        "id": 0,
        "max": 2.0,
        "min": 0.0
      }
    ]
  },
  "granulator": {
    "args": {},
    "code": 51,
    "inputs": [
      {
        "name": "audio",
        "signal": "audio"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 80.0,
        "discrete": false,
        "id": 0,
        "max": 500.0,
        "min": 1.0
      },
      {
        "default": 20.0,
        "discrete": false,
        "id": 1,
        "max": 100.0,
        "min": 1.0
      },
      {
        "default": 0.5,
        "discrete": false,
        "id": 2,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 3,
        "max": 24.0,
        "min": -24.0
      },
      {
        "default": 0.2,
        "discrete": false,
        "id": 4,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 5,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 6,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 7,
        "max": 4.0,
        "min": 0.0
      },
      {
        "default": 1.0,
        "discrete": true,
        "id": 8,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 9,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 10,
        "max": 1.0,
        "min": 0.0
      }
    ]
  },
  "input.raw": {
    "args": {},
    "code": 0,
    "inputs": [],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": []
  },
  "input.sidechain": {
    "args": {},
    "code": 65,
    "inputs": [],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": []
  },
  "lfo": {
    "args": {
      "a": 2.0
    },
    "code": 14,
    "inputs": [],
    "outputs": [
      {
        "name": "out",
        "signal": "control"
      },
      {
        "name": "inv",
        "signal": "control"
      },
      {
        "name": "uni",
        "signal": "control"
      }
    ],
    "parameters": [
      {
        "default": 0.0,
        "discrete": true,
        "id": 0,
        "max": 2.0,
        "min": 0.0
      },
      {
        "default": 2.0,
        "discrete": false,
        "id": 1,
        "max": 20.0,
        "min": 0.05
      }
    ]
  },
  "loop-capture": {
    "args": {
      "a": 2.0,
      "b": 1.0
    },
    "code": 20,
    "inputs": [
      {
        "name": "audio",
        "signal": "audio"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 0.0,
        "discrete": true,
        "id": 0,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 1,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 2,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 3,
        "max": 2.0,
        "min": 0.25
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 4,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 5,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.5,
        "discrete": false,
        "id": 6,
        "max": 1.0,
        "min": 0.0
      }
    ]
  },
  "main-voice-bank": {
    "args": {
      "a": 9.0
    },
    "code": 64,
    "inputs": [
      {
        "name": "midi",
        "signal": "midi"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 0.0,
        "discrete": true,
        "id": 0,
        "max": 4.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 1,
        "max": 1.0,
        "min": -1.0
      },
      {
        "default": 60.0,
        "discrete": false,
        "id": 2,
        "max": 84.0,
        "min": 36.0
      },
      {
        "default": 2.0,
        "discrete": true,
        "id": 3,
        "max": 2.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 4,
        "max": 24.0,
        "min": -24.0
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 5,
        "max": 2.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 6,
        "max": 5.0,
        "min": 0.0
      },
      {
        "default": 0.5,
        "discrete": false,
        "id": 7,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.5,
        "discrete": false,
        "id": 8,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 9,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 1.0,
        "discrete": true,
        "id": 10,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.005,
        "discrete": false,
        "id": 11,
        "max": 0.5,
        "min": 0.001
      },
      {
        "default": 0.08,
        "discrete": false,
        "id": 12,
        "max": 1.0,
        "min": 0.001
      },
      {
        "default": 0.8,
        "discrete": false,
        "id": 13,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.16,
        "discrete": false,
        "id": 14,
        "max": 2.0,
        "min": 0.001
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 15,
        "max": 2.0,
        "min": 0.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 16,
        "max": 4.0,
        "min": 0.25
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 17,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.2,
        "discrete": false,
        "id": 18,
        "max": 0.6,
        "min": 0.05
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 19,
        "max": 1.0,
        "min": 0.0
      }
    ]
  },
  "midi-input": {
    "args": {},
    "code": 54,
    "inputs": [],
    "outputs": [
      {
        "name": "out",
        "signal": "midi"
      }
    ],
    "parameters": []
  },
  "midi-transpose": {
    "args": {
      "a": 0.0
    },
    "code": 55,
    "inputs": [
      {
        "name": "midi",
        "signal": "midi"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "midi"
      }
    ],
    "parameters": [
      {
        "default": 0.0,
        "discrete": false,
        "id": 0,
        "max": 24.0,
        "min": -24.0
      }
    ]
  },
  "mixer9": {
    "args": {
      "a": 9.0,
      "b": 1.0
    },
    "code": 9,
    "inputs": [
      {
        "name": "in-1",
        "signal": "audio"
      },
      {
        "name": "in-2",
        "signal": "audio"
      },
      {
        "name": "in-3",
        "signal": "audio"
      },
      {
        "name": "in-4",
        "signal": "audio"
      },
      {
        "name": "in-5",
        "signal": "audio"
      },
      {
        "name": "in-6",
        "signal": "audio"
      },
      {
        "name": "in-7",
        "signal": "audio"
      },
      {
        "name": "in-8",
        "signal": "audio"
      },
      {
        "name": "in-9",
        "signal": "audio"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 1.0,
        "discrete": false,
        "id": 0,
        "max": 2.0,
        "min": 0.0
      }
    ]
  },
  "modulated-gain": {
    "args": {
      "a": 0.5,
      "b": 0.4
    },
    "code": 15,
    "inputs": [
      {
        "name": "audio",
        "signal": "audio"
      },
      {
        "name": "cv",
        "signal": "control"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 0.5,
        "discrete": false,
        "id": 0,
        "max": 2.0,
        "min": 0.0
      },
      {
        "default": 0.4,
        "discrete": false,
        "id": 1,
        "max": 2.0,
        "min": -2.0
      }
    ]
  },
  "modulated-svf": {
    "args": {
      "a": 2000.0
    },
    "code": 16,
    "inputs": [
      {
        "name": "audio",
        "signal": "audio"
      },
      {
        "name": "cv",
        "signal": "control"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 0.0,
        "discrete": true,
        "id": 0,
        "max": 3.0,
        "min": 0.0
      },
      {
        "default": 3200.0,
        "discrete": false,
        "id": 1,
        "max": 20000.0,
        "min": 20.0
      },
      {
        "default": 0.75,
        "discrete": false,
        "id": 2,
        "max": 1.0,
        "min": 0.1
      },
      {
        "default": 2000.0,
        "discrete": false,
        "id": 3,
        "max": 20000.0,
        "min": 0.0
      }
    ]
  },
  "noise": {
    "args": {
      "a": 0.08,
      "b": 0.5
    },
    "code": 13,
    "inputs": [],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 0.08,
        "discrete": false,
        "id": 0,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.5,
        "discrete": false,
        "id": 1,
        "max": 1.0,
        "min": 0.0
      }
    ]
  },
  "oscillator": {
    "args": {
      "a": 220.0,
      "b": 0.4
    },
    "code": 11,
    "inputs": [
      {
        "name": "sync",
        "signal": "audio"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 0.0,
        "discrete": true,
        "id": 0,
        "max": 4.0,
        "min": 0.0
      },
      {
        "default": 220.0,
        "discrete": false,
        "id": 1,
        "max": 16000.0,
        "min": 20.0
      },
      {
        "default": 0.4,
        "discrete": false,
        "id": 2,
        "max": 1.0,
        "min": 0.0
      }
    ]
  },
  "output": {
    "args": {},
    "code": 7,
    "inputs": [
      {
        "name": "in",
        "signal": "audio"
      }
    ],
    "outputs": [],
    "parameters": []
  },
  "phase-vocoder": {
    "args": {},
    "code": 62,
    "inputs": [
      {
        "name": "audio",
        "signal": "audio"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 0.0,
        "discrete": true,
        "id": 0,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 1,
        "max": 24.0,
        "min": -24.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 2,
        "max": 4.0,
        "min": 0.25
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 3,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 11.0,
        "discrete": true,
        "id": 4,
        "max": 12.0,
        "min": 9.0
      }
    ]
  },
  "pulse-oscillator": {
    "args": {
      "a": 220.0,
      "b": 0.4
    },
    "code": 70,
    "inputs": [
      {
        "name": "sync",
        "signal": "audio"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 220.0,
        "discrete": false,
        "id": 1,
        "max": 16000.0,
        "min": 20.0
      },
      {
        "default": 0.4,
        "discrete": false,
        "id": 2,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.25,
        "discrete": false,
        "id": 4,
        "max": 0.99,
        "min": 0.01
      }
    ]
  },
  "retrospective-capture": {
    "args": {
      "a": 30.0,
      "b": 0.0
    },
    "code": 66,
    "inputs": [
      {
        "name": "audio",
        "signal": "audio"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": []
  },
  "ring-modulator": {
    "args": {},
    "code": 42,
    "inputs": [
      {
        "name": "carrier",
        "signal": "audio"
      },
      {
        "name": "modulator",
        "signal": "audio"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 180.0,
        "discrete": false,
        "id": 0,
        "max": 8000.0,
        "min": 0.1
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 1,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 2,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 3,
        "max": 180.0,
        "min": 0.0
      },
      {
        "default": 1.0,
        "discrete": true,
        "id": 4,
        "max": 1.0,
        "min": 0.0
      }
    ]
  },
  "sample-hold": {
    "args": {
      "a": 0.0
    },
    "code": 32,
    "inputs": [
      {
        "name": "cv",
        "signal": "control"
      },
      {
        "name": "trigger",
        "signal": "control"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "control"
      }
    ],
    "parameters": [
      {
        "default": 0.0,
        "discrete": true,
        "id": 0,
        "max": 2.0,
        "min": 0.0
      }
    ]
  },
  "sample-instrument": {
    "args": {},
    "code": 27,
    "inputs": [
      {
        "name": "midi",
        "signal": "midi"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 60.0,
        "discrete": false,
        "id": 0,
        "max": 84.0,
        "min": 36.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 1,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.25,
        "discrete": false,
        "id": 2,
        "max": 0.5,
        "min": 0.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 3,
        "max": 2.0,
        "min": 0.25
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 4,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 5,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 6,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 7,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 8,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.08,
        "discrete": false,
        "id": 9,
        "max": 0.5,
        "min": 0.0
      },
      {
        "default": 0.01,
        "discrete": false,
        "id": 10,
        "max": 0.2,
        "min": 0.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 11,
        "max": 4.0,
        "min": 1.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 12,
        "max": 100.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 13,
        "max": 1.0,
        "min": 0.0
      }
    ]
  },
  "sample-region": {
    "args": {},
    "code": 26,
    "inputs": [
      {
        "name": "midi",
        "signal": "midi"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 1.0,
        "discrete": false,
        "id": 0,
        "max": 2.0,
        "min": 0.25
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 1,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": true,
        "id": 2,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 3,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 4,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 1.0,
        "discrete": false,
        "id": 5,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.08,
        "discrete": false,
        "id": 8,
        "max": 0.5,
        "min": 0.0
      },
      {
        "default": 1.0,
        "discrete": true,
        "id": 9,
        "max": 8.0,
        "min": 1.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 10,
        "max": 100.0,
        "min": 0.0
      },
      {
        "default": 0.0,
        "discrete": false,
        "id": 11,
        "max": 1.0,
        "min": 0.0
      }
    ]
  },
  "slew-control": {
    "args": {
      "a": 16.0,
      "b": 16.0
    },
    "code": 30,
    "inputs": [
      {
        "name": "cv",
        "signal": "control"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "control"
      }
    ],
    "parameters": [
      {
        "default": 16.0,
        "discrete": false,
        "id": 0,
        "max": 1024.0,
        "min": 1.0
      },
      {
        "default": 16.0,
        "discrete": false,
        "id": 1,
        "max": 1024.0,
        "min": 1.0
      }
    ]
  },
  "stereo-widener": {
    "args": {},
    "code": 38,
    "inputs": [
      {
        "name": "audio",
        "signal": "audio"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 1.0,
        "discrete": false,
        "id": 0,
        "max": 2.0,
        "min": 0.0
      },
      {
        "default": 120.0,
        "discrete": false,
        "id": 1,
        "max": 500.0,
        "min": 20.0
      },
      {
        "default": 1.0,
        "discrete": true,
        "id": 2,
        "max": 1.0,
        "min": 0.0
      }
    ]
  },
  "sum2": {
    "args": {
      "a": 1.0,
      "b": 1.0
    },
    "code": 4,
    "inputs": [
      {
        "name": "a",
        "signal": "audio"
      },
      {
        "name": "b",
        "signal": "audio"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": []
  },
  "svf": {
    "args": {},
    "code": 6,
    "inputs": [
      {
        "name": "audio",
        "signal": "audio"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 0.0,
        "discrete": true,
        "id": 0,
        "max": 3.0,
        "min": 0.0
      },
      {
        "default": 3200.0,
        "discrete": false,
        "id": 1,
        "max": 20000.0,
        "min": 20.0
      },
      {
        "default": 0.75,
        "discrete": false,
        "id": 2,
        "max": 1.0,
        "min": 0.1
      }
    ]
  },
  "voice-synth": {
    "args": {},
    "code": 10,
    "inputs": [
      {
        "name": "midi",
        "signal": "midi"
      }
    ],
    "outputs": [
      {
        "name": "out",
        "signal": "audio"
      }
    ],
    "parameters": [
      {
        "default": 0.0,
        "discrete": true,
        "id": 0,
        "max": 3.0,
        "min": 0.0
      },
      {
        "default": 0.01,
        "discrete": false,
        "id": 1,
        "max": 2.0,
        "min": 0.001
      },
      {
        "default": 0.12,
        "discrete": false,
        "id": 2,
        "max": 2.0,
        "min": 0.001
      },
      {
        "default": 0.65,
        "discrete": false,
        "id": 3,
        "max": 1.0,
        "min": 0.0
      },
      {
        "default": 0.18,
        "discrete": false,
        "id": 4,
        "max": 3.0,
        "min": 0.001
      },
      {
        "default": 0.25,
        "discrete": false,
        "id": 5,
        "max": 1.0,
        "min": 0.0
      }
    ]
  }
};
