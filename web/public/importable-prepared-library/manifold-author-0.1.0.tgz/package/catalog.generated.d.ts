// Generated from manifold-core graph metadata. Run scripts/update-port-catalog.sh.
export declare const PORT_CATALOG: {
  readonly "attenuverter-bias": {
    readonly code: 31;
    readonly args: { readonly a: 1; readonly b: 0; };
    readonly inputs: readonly [{ readonly name: "cv"; readonly signal: "control" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "control" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "audio-fm": {
    readonly code: 71;
    readonly args: {  };
    readonly inputs: readonly [{ readonly name: "carrier"; readonly signal: "audio" }, { readonly name: "modulator"; readonly signal: "audio" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "audio-sync": {
    readonly code: 72;
    readonly args: {  };
    readonly inputs: readonly [{ readonly name: "carrier"; readonly signal: "audio" }, { readonly name: "modulator"; readonly signal: "audio" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "crossfader": {
    readonly code: 8;
    readonly args: { readonly a: 0; readonly b: 1; };
    readonly inputs: readonly [{ readonly name: "a"; readonly signal: "audio" }, { readonly name: "b"; readonly signal: "audio" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "cv-compare": {
    readonly code: 68;
    readonly args: {  };
    readonly inputs: readonly [{ readonly name: "cv"; readonly signal: "control" }];
    readonly outputs: readonly [{ readonly name: "gate"; readonly signal: "control" }, { readonly name: "trig"; readonly signal: "control" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "cv-mix": {
    readonly code: 33;
    readonly args: { readonly a: 1; readonly b: 0.5; };
    readonly inputs: readonly [{ readonly name: "in-1"; readonly signal: "control" }, { readonly name: "in-2"; readonly signal: "control" }, { readonly name: "in-3"; readonly signal: "control" }, { readonly name: "in-4"; readonly signal: "control" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "control" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "cv-range": {
    readonly code: 69;
    readonly args: {  };
    readonly inputs: readonly [{ readonly name: "cv"; readonly signal: "control" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "control" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "distortion": {
    readonly code: 17;
    readonly args: { readonly a: 4; readonly b: 0.7; };
    readonly inputs: readonly [{ readonly name: "audio"; readonly signal: "audio" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "effect-slot-legacy": {
    readonly code: 52;
    readonly args: { readonly a: 0; readonly b: 0; };
    readonly inputs: readonly [{ readonly name: "audio"; readonly signal: "audio" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "eq8": {
    readonly code: 36;
    readonly args: {  };
    readonly inputs: readonly [{ readonly name: "audio"; readonly signal: "audio" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "extended-oscillator": {
    readonly code: 73;
    readonly args: { readonly a: 220; readonly b: 0; };
    readonly inputs: readonly [{ readonly name: "sync"; readonly signal: "audio" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "fixed-gain": {
    readonly code: 67;
    readonly args: { readonly a: 4; };
    readonly inputs: readonly [{ readonly name: "audio"; readonly signal: "audio" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "gain": {
    readonly code: 3;
    readonly args: { readonly a: 0.7; };
    readonly inputs: readonly [{ readonly name: "audio"; readonly signal: "audio" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "granulator": {
    readonly code: 51;
    readonly args: {  };
    readonly inputs: readonly [{ readonly name: "audio"; readonly signal: "audio" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "input.raw": {
    readonly code: 0;
    readonly args: {  };
    readonly inputs: readonly [];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "input.sidechain": {
    readonly code: 65;
    readonly args: {  };
    readonly inputs: readonly [];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "lfo": {
    readonly code: 14;
    readonly args: { readonly a: 2; };
    readonly inputs: readonly [];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "control" }, { readonly name: "inv"; readonly signal: "control" }, { readonly name: "uni"; readonly signal: "control" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "loop-capture": {
    readonly code: 20;
    readonly args: { readonly a: 2; readonly b: 1; };
    readonly inputs: readonly [{ readonly name: "audio"; readonly signal: "audio" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "main-voice-bank": {
    readonly code: 64;
    readonly args: { readonly a: 9; };
    readonly inputs: readonly [{ readonly name: "midi"; readonly signal: "midi" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "midi-input": {
    readonly code: 54;
    readonly args: {  };
    readonly inputs: readonly [];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "midi" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "midi-transpose": {
    readonly code: 55;
    readonly args: { readonly a: 0; };
    readonly inputs: readonly [{ readonly name: "midi"; readonly signal: "midi" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "midi" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "mixer9": {
    readonly code: 9;
    readonly args: { readonly a: 9; readonly b: 1; };
    readonly inputs: readonly [{ readonly name: "in-1"; readonly signal: "audio" }, { readonly name: "in-2"; readonly signal: "audio" }, { readonly name: "in-3"; readonly signal: "audio" }, { readonly name: "in-4"; readonly signal: "audio" }, { readonly name: "in-5"; readonly signal: "audio" }, { readonly name: "in-6"; readonly signal: "audio" }, { readonly name: "in-7"; readonly signal: "audio" }, { readonly name: "in-8"; readonly signal: "audio" }, { readonly name: "in-9"; readonly signal: "audio" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "modulated-gain": {
    readonly code: 15;
    readonly args: { readonly a: 0.5; readonly b: 0.4; };
    readonly inputs: readonly [{ readonly name: "audio"; readonly signal: "audio" }, { readonly name: "cv"; readonly signal: "control" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "modulated-svf": {
    readonly code: 16;
    readonly args: { readonly a: 2000; };
    readonly inputs: readonly [{ readonly name: "audio"; readonly signal: "audio" }, { readonly name: "cv"; readonly signal: "control" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "noise": {
    readonly code: 13;
    readonly args: { readonly a: 0.08; readonly b: 0.5; };
    readonly inputs: readonly [];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "oscillator": {
    readonly code: 11;
    readonly args: { readonly a: 220; readonly b: 0.4; };
    readonly inputs: readonly [{ readonly name: "sync"; readonly signal: "audio" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "output": {
    readonly code: 7;
    readonly args: {  };
    readonly inputs: readonly [{ readonly name: "in"; readonly signal: "audio" }];
    readonly outputs: readonly [];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "phase-vocoder": {
    readonly code: 62;
    readonly args: {  };
    readonly inputs: readonly [{ readonly name: "audio"; readonly signal: "audio" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "pulse-oscillator": {
    readonly code: 70;
    readonly args: { readonly a: 220; readonly b: 0.4; };
    readonly inputs: readonly [{ readonly name: "sync"; readonly signal: "audio" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "retrospective-capture": {
    readonly code: 66;
    readonly args: { readonly a: 30; readonly b: 0; };
    readonly inputs: readonly [{ readonly name: "audio"; readonly signal: "audio" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "ring-modulator": {
    readonly code: 42;
    readonly args: {  };
    readonly inputs: readonly [{ readonly name: "carrier"; readonly signal: "audio" }, { readonly name: "modulator"; readonly signal: "audio" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "sample-hold": {
    readonly code: 32;
    readonly args: { readonly a: 0; };
    readonly inputs: readonly [{ readonly name: "cv"; readonly signal: "control" }, { readonly name: "trigger"; readonly signal: "control" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "control" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "sample-instrument": {
    readonly code: 27;
    readonly args: {  };
    readonly inputs: readonly [{ readonly name: "midi"; readonly signal: "midi" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "sample-region": {
    readonly code: 26;
    readonly args: {  };
    readonly inputs: readonly [{ readonly name: "midi"; readonly signal: "midi" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "slew-control": {
    readonly code: 30;
    readonly args: { readonly a: 16; readonly b: 16; };
    readonly inputs: readonly [{ readonly name: "cv"; readonly signal: "control" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "control" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "stereo-widener": {
    readonly code: 38;
    readonly args: {  };
    readonly inputs: readonly [{ readonly name: "audio"; readonly signal: "audio" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "sum2": {
    readonly code: 4;
    readonly args: { readonly a: 1; readonly b: 1; };
    readonly inputs: readonly [{ readonly name: "a"; readonly signal: "audio" }, { readonly name: "b"; readonly signal: "audio" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "svf": {
    readonly code: 6;
    readonly args: {  };
    readonly inputs: readonly [{ readonly name: "audio"; readonly signal: "audio" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
  readonly "voice-synth": {
    readonly code: 10;
    readonly args: {  };
    readonly inputs: readonly [{ readonly name: "midi"; readonly signal: "midi" }];
    readonly outputs: readonly [{ readonly name: "out"; readonly signal: "audio" }];
    readonly parameters: readonly { readonly id: number; readonly min: number; readonly max: number; readonly default: number; readonly discrete: boolean }[];
  };
};
export type PrimitiveType = keyof typeof PORT_CATALOG;
export type SignalType = "audio" | "control" | "midi";
export interface PortDescription { readonly name: string; readonly signal: SignalType; }
export type PrimitiveDescription = typeof PORT_CATALOG[PrimitiveType];
