const MAX_FRAMES = 1_440_000;
export const MAX_ASSET_BYTES = 80 * 1024 * 1024;
export const SAMPLE_TYPES = new Set(['sample-region', 'sample-instrument', 'granulator', 'main-voice-bank']);
export const PCM_ASSET_TYPES = new Set([...SAMPLE_TYPES, 'loop-capture']);

function encodedBytes(bytes) {
  let text = '';
  for (let start = 0; start < bytes.length; start += 8190) {
    text += btoa(String.fromCharCode(...bytes.subarray(start, start + 8190)));
  }
  return text;
}

function validMetadata({ sourceRate, frames, label }) {
  return Number.isInteger(sourceRate) && sourceRate >= 8000 && sourceRate <= 384000
    && Number.isInteger(frames) && frames >= 1
    && frames <= Math.min(sourceRate * 30, MAX_FRAMES)
    && typeof label === 'string' && new TextEncoder().encode(label).length <= 200;
}

export function encodeSampleAsset(nodeId, stereo, sourceRate, label) {
  const frames = stereo?.length / 2;
  if (!(stereo instanceof Float32Array) || !validMetadata({ sourceRate, frames, label })
    || stereo.some(sample => !Number.isFinite(sample))) {
    throw new TypeError('Invalid decoded stereo sample');
  }
  const bytes = new Uint8Array(stereo.length * 4);
  const view = new DataView(bytes.buffer);
  for (let index = 0; index < stereo.length; index++) view.setFloat32(index * 4, stereo[index], true);
  return { nodeId, sourceRate, frames, label, pcmF32Base64: encodedBytes(bytes) };
}

export function decodeSampleAsset(asset) {
  if (!asset || typeof asset !== 'object' || Array.isArray(asset)
    || Object.keys(asset).length !== 5
    || !['nodeId', 'sourceRate', 'frames', 'label', 'pcmF32Base64']
      .every(key => Object.hasOwn(asset, key))
    || !Number.isInteger(asset.nodeId) || asset.nodeId < 1 || asset.nodeId > 65535
    || !validMetadata(asset) || typeof asset.pcmF32Base64 !== 'string'
    || asset.pcmF32Base64.length !== 4 * Math.ceil(asset.frames * 8 / 3)
    || !/^[A-Za-z0-9+/]*={0,2}$/.test(asset.pcmF32Base64)) {
    throw new TypeError('Invalid portable sample asset');
  }
  const binary = atob(asset.pcmF32Base64);
  if (binary.length !== asset.frames * 8) throw new TypeError('Invalid PCM byte count');
  const bytes = Uint8Array.from(binary, character => character.charCodeAt(0));
  if (encodedBytes(bytes) !== asset.pcmF32Base64) throw new TypeError('Noncanonical PCM encoding');
  const view = new DataView(bytes.buffer);
  const stereo = new Float32Array(asset.frames * 2);
  for (let index = 0; index < stereo.length; index++) {
    const value = view.getFloat32(index * 4, true);
    if (!Number.isFinite(value)) throw new TypeError('Nonfinite PCM sample');
    stereo[index] = value;
  }
  return { nodeId: asset.nodeId, sourceRate: asset.sourceRate, stereo };
}
