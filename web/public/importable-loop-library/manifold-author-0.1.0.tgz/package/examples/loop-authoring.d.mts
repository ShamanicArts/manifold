import type { GraphWorkspace, GraphWorkspaceProject, LiveGraphSession } from '../index.js';
import type { BrowserGraphHost } from '../browser.js';
import type { createFourLayerLoopController } from './four-layer-loops.mjs';
export function buildGraph(): GraphWorkspace;
export function createProject(host: Pick<BrowserGraphHost, 'setRoute' | 'setParameter' | 'setParameterBatch' | 'replaceGraph' | 'readPublishedParameters' | 'snapshotLoop'>, graph?: GraphWorkspace): Readonly<{
  session: LiveGraphSession; layers: ReturnType<typeof createFourLayerLoopController>;
  toProject(): GraphWorkspaceProject; synchronizeParameters(): Promise<GraphWorkspaceProject>;
  snapshot(): Promise<GraphWorkspaceProject>; setInsert(enabled: boolean, mix?: number): Promise<GraphWorkspaceProject>;
}>;
