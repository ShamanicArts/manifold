// Ordinary public graph composition. This audition does not implement Main's
// quantized transport or seek/scrub behavior.
import { createGraphWorkspace, createLiveGraphSession } from '../index.js';
import { addFourLayerLoopSources, createFourLayerLoopController, snapshotWithLoopAudio } from './four-layer-loops.mjs';
export function buildGraph() {
  const graph = createGraphWorkspace(), tone = graph.add('oscillator', { id: 4 }), trim = graph.add('fixed-gain', { id: 5 });
  graph.registerInstance('/loop/audition/source', tone); graph.setParameter(tone, 1, 220);
  graph.registerInstance('/loop/audition/trim', trim);
  graph.connect(tone.output('out'), trim.input('audio'));
  const loops = addFourLayerLoopSources(graph, { input: trim.output('out'), registerSampleSources: false });
  const mix = graph.add('mixer9', { id: 8 }); graph.registerInstance('/loop/audition/mix', mix);
  graph.setParameter(mix, 0, .25);
  loops.forEach((loop, index) => graph.connect(loop.output('out'), mix.input(`in-${index + 1}`)));
  const capture = graph.add('retrospective-capture', { id: 80 });
  graph.registerInstance('/loop/audition/history', capture); graph.connect(trim.output('out'), capture.input('audio'));
  graph.connect(mix.output('out'), graph.output.input('in'));
  return graph;
}
export function createProject(host, graph = buildGraph()) {
  const session = createLiveGraphSession(graph, route => host.setRoute(route), edit => host.setParameter(edit),
    state => host.replaceGraph(state), edits => host.setParameterBatch(edits), () => host.readPublishedParameters());
  return Object.freeze({ session, layers: createFourLayerLoopController(session), toProject: () => session.toProject(),
    synchronizeParameters: () => session.adoptPublishedParameters([]),
    async snapshot() { const state = await session.adoptPublishedParameters([]); return snapshotWithLoopAudio(state, id => host.snapshotLoop(id)); },
    setInsert: (enabled, mix = .4) => session.transaction(graph => {
      const mixer = graph.findInstance('/loop/audition/mix'), old = graph.findInstance('/loop/audition/insert');
      graph.disconnect(graph.output.input('in'));
      if (enabled) {
        const insert = old ?? graph.add('distortion', { id: 9 }); graph.registerInstance('/loop/audition/insert', insert);
        graph.setParameter(insert, 0, 4); graph.setParameter(insert, 1, mix); graph.setParameter(insert, 2, 1);
        if (!old) graph.connect(mixer.output('out'), insert.input('audio'));
        graph.connect(insert.output('out'), graph.output.input('in'));
      } else { if (old) graph.remove(old); graph.connect(mixer.output('out'), graph.output.input('in')); }
    }),
  });
}
